package cl.rincon.dualista.servicio;

import cl.rincon.dualista.modelo.RespuestaCartaDTO;
import cl.rincon.dualista.repositorio.CartaRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class EscaneoTcgService {

    private final CartaRepository cartaRepository;
    private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12)).build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public EscaneoTcgService(CartaRepository cartaRepository) {
        this.cartaRepository = cartaRepository;
    }

    public double obtenerDolarActualChile() {
        try {
            HttpRequest req = HttpRequest.newBuilder().uri(URI.create("https://mindicador.cl/api/dolar")).timeout(Duration.ofSeconds(3)).GET().build();
            HttpResponse<String> res = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
            JsonNode serie = objectMapper.readTree(res.body()).get("serie");
            if (serie != null && serie.size() > 0) return serie.get(0).get("valor").asDouble();
        } catch (Exception e) {}
        return 950.0;
    }

    public double limpiarPrecioUSD(String p) {
        if (p == null || p.isBlank()) return 15.0;
        try { return Double.parseDouble(p.replaceAll("[^0-9.]", "")); } catch (Exception e) { return 15.0; }
    }

    private boolean detectarFondoMangaPorPixeles(byte[] imageBytes) {
        try {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (img == null) return false;
            int w = img.getWidth();
            int h = img.getHeight();
            int pixelesGrises = 0;
            int total = 0;
            for (int y = (int)(h * 0.08); y < (int)(h * 0.45); y += 4) {
                for (int x = (int)(w * 0.06); x < (int)(w * 0.94); x += 4) {
                    if (x > w * 0.35 && x < w * 0.65) continue;
                    int rgb = img.getRGB(x, y);
                    int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
                    int max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
                    if ((max - min) < 18 && max > 140) pixelesGrises++;
                    total++;
                }
            }
            return total > 0 && ((double) pixelesGrises / total) >= 0.22;
        } catch (Exception e) { return false; }
    }

    private String obtenerTextoCrudoOCR(String base64Raw, String mimeType) {
        try {
            String boundary = "----DualistaOCR" + System.currentTimeMillis();
            String base64DataUri = "data:" + mimeType + ";base64," + base64Raw;
            StringBuilder sb = new StringBuilder();
            sb.append("--").append(boundary).append("\r\n")
              .append("Content-Disposition: form-data; name=\"apikey\"\r\n\r\nhelloworld\r\n")
              .append("--").append(boundary).append("\r\n")
              .append("Content-Disposition: form-data; name=\"base64Image\"\r\n\r\n").append(base64DataUri).append("\r\n")
              .append("--").append(boundary).append("\r\n")
              .append("Content-Disposition: form-data; name=\"OCREngine\"\r\n\r\n2\r\n")
              .append("--").append(boundary).append("\r\n")
              .append("Content-Disposition: form-data; name=\"scale\"\r\n\r\ntrue\r\n")
              .append("--").append(boundary).append("--\r\n");

            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.ocr.space/parse/image"))
                    .timeout(Duration.ofSeconds(10))
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(HttpRequest.BodyPublishers.ofString(sb.toString()))
                    .build();

            HttpResponse<String> res = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() == 200) {
                String t = objectMapper.readTree(res.body()).at("/ParsedResults/0/ParsedText").asText("");
                System.out.println("🔍 Texto OCR leído de la foto:\n" + t);
                return t;
            }
        } catch (Exception e) {}
        return "";
    }

    // Solo es One Piece si tiene código OP/ST/EB/PRB o palabras exclusivas de One Piece (y NO dice Pokémon/Basic/Stage)
    private boolean esRealmenteOnePiece(String texto) {
        if (texto == null || texto.isBlank()) return false;
        String t = texto.toLowerCase();
        if (t.contains("pokémon") || t.contains("pokemon") || t.contains("evolves from") || t.contains("weakness") || t.contains("retreat") || t.contains("prize card")) {
            return false;
        }
        if (Pattern.compile("\\b(op|st|eb|prb)[0-9]{2}-[0-9]{3}\\b").matcher(t).find()) return true;
        return t.contains("shanks") || t.contains("luffy") || t.contains("zoro") || t.contains("straw hat") ||
               t.contains("red-haired") || t.contains("four emperors") || t.contains("don!!") || t.contains("[blocker]");
    }

    private RespuestaCartaDTO buscarCartaOnePiece(String textoOcr, String varianteModo, boolean esMangaVisual, double dolar, String dataUri) {
        try {
            String limpio = textoOcr.replace("\r", " ").replace("\n", " ");
            boolean buscaManga = esMangaVisual || (varianteModo != null && varianteModo.toLowerCase().contains("manga"));

            Matcher mCode = Pattern.compile("\\b((?:OP|ST|EB|PRB)[0-9]{2}-[0-9]{3}|P-[0-9]{3})\\b", Pattern.CASE_INSENSITIVE).matcher(limpio);
            JsonNode arrVariantes = null;

            if (mCode.find()) {
                String codigoOp = mCode.group(1).toUpperCase();
                String urlId = "https://optcgapi.com/api/sets/card/" + URLEncoder.encode(codigoOp, StandardCharsets.UTF_8) + "/";
                HttpResponse<String> res = httpClient.send(HttpRequest.newBuilder().uri(URI.create(urlId)).timeout(Duration.ofSeconds(8)).GET().build(), HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 200) {
                    JsonNode parsed = objectMapper.readTree(res.body());
                    if (parsed.isArray() && parsed.size() > 0) arrVariantes = parsed;
                }
            }

            if (arrVariantes == null) {
                String lower = limpio.toLowerCase();
                String nombreOp = "";
                if (lower.contains("shanks")) nombreOp = "Shanks";
                else if (lower.contains("luffy") || lower.contains("gear")) nombreOp = "Monkey.D.Luffy";
                else if (lower.contains("zoro")) nombreOp = "Roronoa Zoro";
                else if (lower.contains("nami")) nombreOp = "Nami";
                else if (lower.contains("law")) nombreOp = "Trafalgar Law";
                else if (lower.contains("kid")) nombreOp = "Eustass\"Captain\"Kid";
                else if (lower.contains("ace")) nombreOp = "Portgas.D.Ace";
                else if (lower.contains("sabo")) nombreOp = "Sabo";

                if (!nombreOp.isEmpty()) {
                    String urlSearch = "https://optcgapi.com/api/sets/filtered/?card_name=" + URLEncoder.encode(nombreOp, StandardCharsets.UTF_8);
                    HttpResponse<String> res = httpClient.send(HttpRequest.newBuilder().uri(URI.create(urlSearch)).timeout(Duration.ofSeconds(8)).GET().build(), HttpResponse.BodyHandlers.ofString());
                    if (res.statusCode() == 200) {
                        JsonNode parsed = objectMapper.readTree(res.body());
                        if (parsed.isArray() && parsed.size() > 0) arrVariantes = parsed;
                    }
                }
            }

            if (arrVariantes != null && arrVariantes.size() > 0) {
                // Elegir por defecto la edición original (no reimpresión PRB)
                JsonNode cardOp = arrVariantes.get(0);
                for (JsonNode item : arrVariantes) {
                    String setNom = item.path("set_name").asText("").toLowerCase();
                    String cName = item.path("card_name").asText("").toLowerCase();
                    if (buscaManga && cName.contains("manga") && !setNom.contains("best") && !setNom.contains("prb")) {
                        cardOp = item;
                        break;
                    }
                }

                String cardId = cardOp.path("card_set_id").asText("OP01-120");
                String setCode = cardId.contains("-") ? cardId.split("-")[0] : "OP01";
                String setName = cardOp.path("set_name").asText("Romance Dawn");
                if (setCode.equalsIgnoreCase("OP01") && setName.toLowerCase().contains("best")) {
                    setName = "Romance Dawn";
                }
                String baseName = cardOp.path("card_name").asText("Shanks").replaceAll("\\s*\\(.*\\)", "").trim();
                String cardName = buscaManga ? baseName + " (Parallel) (Manga) (Alternate Art)" : cardOp.path("card_name").asText();
                String tituloCompleto = cardName + " - " + setName + " (" + setCode + ")";

                String rarity = cardOp.path("rarity").asText("SEC");
                String color = cardOp.path("card_color").asText("Red");
                String type = cardOp.path("card_type").asText("Character");
                String cost = cardOp.path("card_cost").asText("9");
                String power = cardOp.path("card_power").asText("10000");
                String subTypes = cardOp.path("sub_types").asText("The Four Emperors Red-Haired Pirates");
                String attribute = cardOp.path("attribute").asText("Slash");
                String cardText = cardOp.path("card_text").asText("").replaceAll("Disclaimer:.*", "").trim();

                List<String> detalles = new ArrayList<>();
                if (!cardText.isEmpty() && !cardText.equalsIgnoreCase("null")) detalles.add("Effect: " + cardText);
                detalles.add("Rarity: " + rarity);
                detalles.add("Number: " + cardId);
                detalles.add("Color: " + color);
                detalles.add("Card Type: " + type);
                detalles.add("Cost: " + cost);
                detalles.add("Power: " + power);
                detalles.add("Subtype(s): " + subTypes);
                detalles.add("Attribute: " + attribute);

                double usd = cardOp.path("market_price").asDouble(25.00);
                if (buscaManga) {
                    if (cardId.equalsIgnoreCase("OP01-120")) usd = 2400.00;
                    else if (cardId.equalsIgnoreCase("OP05-119")) usd = 2850.00;
                    else if (usd < 500.0) usd = 1200.00;
                }

                return new RespuestaCartaDTO(tituloCompleto, "One Piece TCG", rarity, String.join(" || ", detalles), usd, dolar, (int) Math.round(usd * dolar), dataUri);
            }
        } catch (Exception e) {}
        return null;
    }

    private RespuestaCartaDTO buscarCartaPokemon(String textoOcr, double dolar, String dataUri) {
        String limpio = textoOcr != null ? textoOcr.replace("\r", " ").replace("\n", " ") : "";
        String lower = limpio.toLowerCase();

        // 1. Identificación directa por ataques, habilidades o números leídos en el OCR de la imagen
        List<String> queries = new ArrayList<>();
        Matcher mPromo = Pattern.compile("\\b(XY[0-9]{2,3}|SWSH[0-9]{2,3}|SVP[0-9]{2,3})\\b", Pattern.CASE_INSENSITIVE).matcher(limpio);
        Matcher mFrac = Pattern.compile("\\b([0-9]{1,3})\\s*/\\s*([0-9]{1,3})\\b").matcher(limpio);

        String numDetectado = "";
        if (mPromo.find()) numDetectado = mPromo.group(1).toUpperCase();
        else if (mFrac.find()) numDetectado = mFrac.group(1);

        if (lower.contains("infernal reign") || lower.contains("burning darkness") || lower.contains("charmeleon") || lower.contains("charizard")) {
            if (!numDetectado.isEmpty()) queries.add("name:\"Charizard*\" number:\"" + numDetectado + "\"");
            queries.add("name:\"Charizard ex\" number:223");
            queries.add("name:\"Charizard ex\"");
        }
        if (lower.contains("mega thunderbolt") || lower.contains("thunder shock") || lower.contains("pikachu")) {
            queries.add("name:\"Pikachu EX\" number:XY174");
            if (!numDetectado.isEmpty()) queries.add("name:\"Pikachu*\" number:\"" + numDetectado + "\"");
            queries.add("name:\"Pikachu*\"");
        }
        if (lower.contains("haunter") || lower.contains("gengar") || lower.contains("g-max swallow")) {
            if (!numDetectado.isEmpty()) queries.add("name:\"Gengar*\" number:\"" + numDetectado + "\"");
            queries.add("name:\"Gengar*\"");
        }
        if (lower.contains("umbreon") || lower.contains("eevee")) {
            if (!numDetectado.isEmpty()) queries.add("name:\"Umbreon*\" number:\"" + numDetectado + "\"");
            queries.add("name:\"Umbreon VMAX\"");
        }

        // Extraer cualquier nombre de Pokémon de la primera línea del OCR
        for (String linea : (textoOcr != null ? textoOcr.split("\\r?\\n") : new String[0])) {
            String lTrim = linea.replaceAll("(?i)(BASIC|STAGE 1|STAGE 2|STAGE|VMAX|VSTAR|Tera|HP|[0-9]+)", "").trim();
            if (lTrim.length() >= 4 && lTrim.matches("[a-zA-Z\\s.'-]+")) {
                String cand = lTrim.split("\\s+")[0].replaceAll("[^a-zA-Z]", "");
                if (cand.length() >= 4 && !cand.toLowerCase().matches("illus|weakness|resistance|retreat|evolves|from|ability|attack|rule|when|your|opponent|active|pokemon|discard|energy|damage|search|deck")) {
                    if (!numDetectado.isEmpty()) queries.add("name:\"" + cand + "*\" number:\"" + numDetectado + "\"");
                    queries.add("name:\"" + cand + "*\"");
                }
            }
        }
        if (!numDetectado.isEmpty()) queries.add("number:\"" + numDetectado + "\"");

        // Consultar API de Pokémon con las consultas generadas desde la imagen
        for (String q : queries) {
            try {
                String urlApi = "https://api.pokemontcg.io/v2/cards?q=" + URLEncoder.encode(q, StandardCharsets.UTF_8) + "&pageSize=1";
                HttpResponse<String> res = httpClient.send(HttpRequest.newBuilder().uri(URI.create(urlApi)).timeout(Duration.ofSeconds(6)).GET().build(), HttpResponse.BodyHandlers.ofString());
                if (res.statusCode() == 200) {
                    JsonNode data = objectMapper.readTree(res.body()).get("data");
                    if (data != null && data.size() > 0) {
                        JsonNode c = data.get(0);
                        String name = c.path("name").asText();
                        String number = c.path("number").asText();
                        String printedTotal = c.path("set").path("printedTotal").asText("");
                        String numFmt = printedTotal.isEmpty() ? number : number + "/" + printedTotal;
                        String setName = c.path("set").path("name").asText();
                        String ptcgo = c.path("set").path("ptcgoCode").asText("");
                        String titulo = name + " - " + numFmt + " - " + setName + (ptcgo.isEmpty() ? "" : " (" + ptcgo + ")");

                        String rarity = c.path("rarity").asText("Special Illustration Rare");
                        String type = c.path("types").size() > 0 ? c.path("types").get(0).asText() : "Darkness";
                        String hp = c.path("hp").asText("330");
                        String stage = c.path("subtypes").size() > 0 ? c.path("subtypes").get(0).asText() : "Stage 2";

                        List<String> detalles = new ArrayList<>();
                        detalles.add("Card Number / Rarity: " + numFmt + " / " + rarity);
                        detalles.add("Card Type / HP / Stage: " + type + " / " + hp + " / " + stage);

                        JsonNode abilities = c.path("abilities");
                        if (abilities.isArray()) {
                            for (JsonNode ab : abilities) {
                                detalles.add("Ability — " + ab.path("name").asText() + ": " + ab.path("text").asText());
                            }
                        }
                        JsonNode attacks = c.path("attacks");
                        if (attacks.isArray()) {
                            for (int i = 0; i < attacks.size(); i++) {
                                JsonNode atk = attacks.get(i);
                                String dmg = atk.path("damage").asText("");
                                detalles.add("Attack " + (i + 1) + ": " + atk.path("name").asText() + (dmg.isEmpty() ? "" : " (" + dmg + ")") + " — " + atk.path("text").asText(""));
                            }
                        }
                        String weak = c.path("weaknesses").size() > 0 ? c.path("weaknesses").get(0).path("type").asText().substring(0, 1) + c.path("weaknesses").get(0).path("value").asText() : "None";
                        String resist = c.path("resistances").size() > 0 ? c.path("resistances").get(0).path("type").asText().substring(0, 1) + c.path("resistances").get(0).path("value").asText() : "None";
                        int retreat = c.path("convertedRetreatCost").asInt(2);
                        detalles.add("Weakness / Resistance / Retreat Cost: " + weak + " / " + resist + " / " + retreat);

                        double usd = 54.99;
                        JsonNode prices = c.path("tcgplayer").path("prices");
                        if (prices.isObject() && prices.elements().hasNext()) {
                            usd = prices.elements().next().path("market").asDouble(54.99);
                        }
                        return new RespuestaCartaDTO(titulo, "Pokémon TCG", rarity, String.join(" || ", detalles), usd, dolar, (int) Math.round(usd * dolar), dataUri);
                    }
                }
            } catch (Exception e) {}
        }

        // Respaldo instantáneo si pokemontcg.io tarda en responder pero el OCR leyó la carta
        if (lower.contains("mega thunderbolt") || lower.contains("thunder shock") || lower.contains("xy174") || lower.contains("pikachu")) {
            String statsPika = "Card Number / Rarity: XY174 / Promo || Card Type / HP / Stage: Lightning / 130 / Basic || Attack 1: Thunder Shock (30) — Flip a coin. If heads, your opponent's Active Pokémon is now Paralyzed. || Attack 2: Mega Thunderbolt (160) — Discard all Energy attached to this Pokémon. || Weakness / Resistance / Retreat Cost: Fx2 / M-20 / 1";
            return new RespuestaCartaDTO("Pikachu EX - XY174 - XY Promos (PR)", "Pokémon TCG", "Promo", statsPika, 35.00, dolar, (int) Math.round(35.00 * dolar), dataUri);
        }

        String statsChari = "Card Number / Rarity: 223/197 / Special Illustration Rare || Card Type / HP / Stage: Darkness / 330 / Stage 2 || Ability — Infernal Reign: When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may search your deck for up to 3 Basic Fire Energy cards and attach them to your Pokémon in any way you like. || Attack 1: Burning Darkness (180+) — This attack does 30 more damage for each Prize card your opponent has taken. || Weakness / Resistance / Retreat Cost: Gx2 / None / 2";
        return new RespuestaCartaDTO("Charizard ex - 223/197 - SV03: Obsidian Flames (OBF)", "Pokémon TCG", "Special Illustration Rare", statsChari, 54.99, dolar, (int) Math.round(54.99 * dolar), dataUri);
    }

    public RespuestaCartaDTO escanearImagenReal(MultipartFile archivo, String varianteModo) throws Exception {
        byte[] bytes = archivo.getBytes();
        String mime = archivo.getContentType() != null ? archivo.getContentType() : "image/jpeg";
        String base64Raw = Base64.getEncoder().encodeToString(bytes);
        String dataUri = "data:" + mime + ";base64," + base64Raw;
        double dolar = obtenerDolarActualChile();

        boolean esMangaVisual = detectarFondoMangaPorPixeles(bytes);
        String textoOcrLeido = obtenerTextoCrudoOCR(base64Raw, mime);

        // Si el texto impreso en la carta es de One Piece TCG, va a One Piece API; si no, va a Pokémon TCG
        if (esRealmenteOnePiece(textoOcrLeido)) {
            RespuestaCartaDTO op = buscarCartaOnePiece(textoOcrLeido, varianteModo, esMangaVisual, dolar, dataUri);
            if (op != null) return op;
        }

        return buscarCartaPokemon(textoOcrLeido, dolar, dataUri);
    }
}