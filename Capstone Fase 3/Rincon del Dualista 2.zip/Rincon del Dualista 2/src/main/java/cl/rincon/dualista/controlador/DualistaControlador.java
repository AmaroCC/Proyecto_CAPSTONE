package cl.rincon.dualista.controlador;

import cl.rincon.dualista.modelo.OrdenCompra;
import cl.rincon.dualista.modelo.RespuestaCartaDTO;
import cl.rincon.dualista.modelo.Usuario;
import cl.rincon.dualista.repositorio.CartaRepository;
import cl.rincon.dualista.repositorio.OrdenCompraRepository;
import cl.rincon.dualista.repositorio.UsuarioRepository;
import cl.rincon.dualista.servicio.EmailService;
import cl.rincon.dualista.servicio.EscaneoTcgService;
import cl.rincon.dualista.servicio.WebpayService;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Controller
public class DualistaControlador {
    private final EscaneoTcgService escaneoService;
    private final WebpayService webpayService;
    private final UsuarioRepository usuarioRepo;
    private final CartaRepository cartaRepo;
    private final OrdenCompraRepository ordenRepo;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;

    public DualistaControlador(EscaneoTcgService escaneoService, WebpayService webpayService, UsuarioRepository usuarioRepo, CartaRepository cartaRepo, OrdenCompraRepository ordenRepo, PasswordEncoder passwordEncoder, EmailService emailService) {
        this.escaneoService = escaneoService;
        this.webpayService = webpayService;
        this.usuarioRepo = usuarioRepo;
        this.cartaRepo = cartaRepo;
        this.ordenRepo = ordenRepo;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    @PostConstruct
    public void inicializarDatosBase() {
        // Cuentas default activas en base de datos (ocultas en la vista de login)
        Usuario admin = usuarioRepo.findByUsernameIgnoreCase("admin").orElse(new Usuario("admin", "admin@dualista.cl", "", "ADMIN", true));
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setRol("ADMIN");
        usuarioRepo.save(admin);

        Usuario cliente = usuarioRepo.findByUsernameIgnoreCase("cliente").orElse(new Usuario("cliente", "cliente@dualista.cl", "", "CLIENTE", true));
        cliente.setPassword(passwordEncoder.encode("cliente123"));
        cliente.setRol("CLIENTE");
        usuarioRepo.save(cliente);

                double d = 950.0;
        java.util.List<RespuestaCartaDTO> loteInicial = java.util.List.of(
            // ================= POKÉMON TCG =================
            new RespuestaCartaDTO("M Rayquaza EX - 98/98 - XY: Ancient Origins (AOR)", "Pokémon TCG", "Shiny Full Art Ultra Rare",
                "Card Number / Rarity: 98/98 / Ultra Rare || Card Type / HP / Stage: Colorless / 220 / Mega || Ability — Δ Evolution: You may play this card from your hand to evolve a Pokémon even during your first turn or the turn you play that Pokémon. || Attack 1: Emerald Break (30x) — This attack does 30 damage times the number of your Benched Pokémon. || Weakness / Resistance / Retreat Cost: Lx2 / F-20 / 1",
                195.00, d, (int)(195.00 * d), "https://images.pokemontcg.io/xy7/98_hires.png"),

            new RespuestaCartaDTO("M Rayquaza EX - 61/108 - XY: Roaring Skies (ROS)", "Pokémon TCG", "Ultra Rare",
                "Card Number / Rarity: 61/108 / Ultra Rare || Card Type / HP / Stage: Dragon / 230 / Mega || Attack 1: Dragon Ascent (300) — Discard 2 Energy attached to this Pokémon. || Weakness / Resistance / Retreat Cost: Yx2 / None / 2",
                48.50, d, (int)(48.50 * d), "https://images.pokemontcg.io/xy6/61_hires.png"),

            new RespuestaCartaDTO("Charizard ex - 199/165 - SV: Pokémon 151 (MEW)", "Pokémon TCG", "Special Illustration Rare",
                "Card Number / Rarity: 199/165 / Special Illustration Rare || Card Type / HP / Stage: Fire / 330 / Stage 2 || Ability — Brave Wings: If this Pokémon has any damage counters on it, it can't attack. || Attack 1: Explosive Vortex (330) — Discard 3 Fire Energy from this Pokémon. || Weakness / Resistance / Retreat Cost: Wx2 / None / 2",
                135.00, d, (int)(135.00 * d), "https://images.pokemontcg.io/sv3pt5/199_hires.png"),

            new RespuestaCartaDTO("Umbreon VMAX - 215/203 - SWSH07: Evolving Skies (EVS)", "Pokémon TCG", "Alt Art Secret Rare",
                "Card Number / Rarity: 215/203 / Alt Art Secret Rare || Card Type / HP / Stage: Darkness / 310 / VMAX || Ability — Dark Signal: When you play this Pokémon from your hand to evolve 1 of your Pokémon during your turn, you may switch 1 of your opponent's Benched Pokémon with their Active Pokémon. || Attack 1: Max Darkness (160) || Weakness / Resistance / Retreat Cost: Gx2 / None / 2",
                920.00, d, (int)(920.00 * d), "https://images.pokemontcg.io/swsh7/215_hires.png"),

            new RespuestaCartaDTO("Giratina V - 186/196 - SWSH11: Lost Origin (LOR)", "Pokémon TCG", "Alternate Full Art",
                "Card Number / Rarity: 186/196 / Ultra Rare || Card Type / HP / Stage: Dragon / 220 / Basic || Attack 1: Abyss Seeking — Look at the top 4 cards of your deck and put 2 of them into your hand. Put the other cards in the Lost Zone. || Attack 2: Shred (160) — This attack's damage isn't affected by any effects on your opponent's Active Pokémon. || Weakness / Resistance / Retreat Cost: None / None / 2",
                365.00, d, (int)(365.00 * d), "https://images.pokemontcg.io/swsh11/186_hires.png"),

            new RespuestaCartaDTO("Gengar VMAX - 271/264 - SWSH08: Fusion Strike (FST)", "Pokémon TCG", "Alt Art Secret Rare",
                "Card Number / Rarity: 271/264 / Secret Rare || Card Type / HP / Stage: Darkness / 320 / VMAX || Attack 1: Fear and Panic (60x) — This attack does 60 damage for each of your opponent's Pokémon V and Pokémon-GX in play. || Attack 2: G-Max Swallow Up (250) — During your next turn, this Pokémon can't attack. || Weakness / Resistance / Retreat Cost: Fx2 / None / 3",
                310.00, d, (int)(310.00 * d), "https://images.pokemontcg.io/swsh8/271_hires.png"),

            new RespuestaCartaDTO("Lugia V - 186/195 - SWSH12: Silver Tempest (SIT)", "Pokémon TCG", "Alternate Full Art",
                "Card Number / Rarity: 186/195 / Ultra Rare || Card Type / HP / Stage: Colorless / 220 / Basic || Attack 1: Read the Wind — Discard a card from your hand. If you do, draw 3 cards. || Attack 2: Aero Dive (130) — You may discard a Stadium in play. || Weakness / Resistance / Retreat Cost: Lx2 / F-30 / 2",
                185.00, d, (int)(185.00 * d), "https://images.pokemontcg.io/swsh12/186_hires.png"),

            new RespuestaCartaDTO("Mewtwo VSTAR - GG44/GG70 - Crown Zenith (CRZ)", "Pokémon TCG", "Galarian Gallery Ultra Rare",
                "Card Number / Rarity: GG44/GG70 / Galarian Gallery || Card Type / HP / Stage: Psychic / 280 / VSTAR || Attack 1: Psy Purge (90x) — Discard up to 3 Psychic Energy from your Pokémon. This attack does 90 damage for each card you discarded in this way. || Attack 2: Star Raid (120) — This attack does 120 damage to each of your opponent's Pokémon V. || Weakness / Resistance / Retreat Cost: Dx2 / F-30 / 2",
                58.00, d, (int)(58.00 * d), "https://images.pokemontcg.io/swsh12pt5gg/GG44_hires.png"),

            new RespuestaCartaDTO("Rayquaza VMAX - 218/203 - SWSH07: Evolving Skies (EVS)", "Pokémon TCG", "Alt Art Secret Rare",
                "Card Number / Rarity: 218/203 / Secret Rare || Card Type / HP / Stage: Dragon / 320 / VMAX || Ability — Azure Pulse: Once during your turn, you may discard your hand and draw 3 cards. || Attack 1: Max Burst (20+ ) — Discard any amount of Basic Fire or Basic Lightning Energy from this Pokémon. This attack does 80 more damage for each card you discarded. || Weakness / Resistance / Retreat Cost: None / None / 2",
                410.00, d, (int)(410.00 * d), "https://images.pokemontcg.io/swsh7/218_hires.png"),

            new RespuestaCartaDTO("Greninja ex - 214/167 - SV06: Twilight Masquerade (TWM)", "Pokémon TCG", "Special Illustration Rare",
                "Card Number / Rarity: 214/167 / Special Illustration Rare || Card Type / HP / Stage: Fighting / 310 / Stage 2 || Attack 1: Shinobi Blade (170) — You may search your deck for any 1 card and put it into your hand. || Attack 2: Mirage Barrage (120) — Discard 2 Energy from this Pokémon. This attack does 120 damage to 2 of your opponent's Pokémon. || Weakness / Resistance / Retreat Cost: Px2 / None / 1",
                275.00, d, (int)(275.00 * d), "https://images.pokemontcg.io/sv6/214_hires.png"),

            // ================= ONE PIECE CARD GAME =================
            new RespuestaCartaDTO("Monkey.D.Luffy (Gear 5) (Parallel) (Manga) - Awakening of the New Era (OP05)", "One Piece TCG", "SEC",
                "Effect: [On Play] DON!! -10: Place all of your Characters other than this Character at the bottom of your deck in any order. Then, take an extra turn after this one. || Rarity: SEC || Number: OP05-119 || Color: Purple || Card Type: Character || Cost: 10 || Power: 12000 || Subtype(s): The Four Emperors / Straw Hat Crew || Attribute: Strike",
                2850.00, d, (int)(2850.00 * d), "https://optcgapi.com/media/static/Card_Images/OP05-119_p2.jpg"),

            new RespuestaCartaDTO("Roronoa Zoro (Parallel) (Manga) - Wings of the Captain (OP06)", "One Piece TCG", "SEC",
                "Effect: [On Play] You may rest 1 of your DON!! cards: K.O. up to 1 of your opponent's Characters with a cost of 4 or less. || Rarity: SEC || Number: OP06-118 || Color: Green || Card Type: Character || Cost: 9 || Power: 9000 || Subtype(s): Supernovas / Straw Hat Crew || Attribute: Slash",
                1150.00, d, (int)(1150.00 * d), "https://optcgapi.com/media/static/Card_Images/OP06-118_p2.jpg"),

            new RespuestaCartaDTO("Trafalgar Law (Parallel) (Manga) - Awakening of the New Era (OP05)", "One Piece TCG", "SR",
                "Effect: [When Attacking] If your opponent has 5 or more cards in their hand, your opponent trashes 1 card from their hand. || Rarity: SR || Number: OP05-069 || Color: Purple || Card Type: Character || Cost: 3 || Power: 5000 || Subtype(s): Heart Pirates || Attribute: Slash",
                640.00, d, (int)(640.00 * d), "https://optcgapi.com/media/static/Card_Images/OP05-069_p2.jpg"),

            new RespuestaCartaDTO("Eustass\"Captain\"Kid (Parallel) (Manga) - Awakening of the New Era (OP05)", "One Piece TCG", "SR",
                "Effect: [Blocker] [On Your Opponent's Attack] [Once Per Turn] You may return 1 of your active DON!! cards to your DON!! deck: Add 1 DON!! card from your DON!! deck and set it as active. || Rarity: SR || Number: OP05-074 || Color: Purple || Card Type: Character || Cost: 5 || Power: 6000 || Subtype(s): Kid Pirates || Attribute: Special",
                520.00, d, (int)(520.00 * d), "https://optcgapi.com/media/static/Card_Images/OP05-074_p2.jpg"),

            new RespuestaCartaDTO("Portgas.D.Ace (Parallel) (Manga) - Paramount War (OP02)", "One Piece TCG", "SR",
                "Effect: [On Play] Give up to 2 of your opponent's Characters -3000 power during this turn. Then, if your Leader's type includes Whitebeard Pirates, this Character gains [Rush] during this turn. || Rarity: SR || Number: OP02-013 || Color: Red || Card Type: Character || Cost: 7 || Power: 7000 || Subtype(s): Whitebeard Pirates || Attribute: Special",
                1480.00, d, (int)(1480.00 * d), "https://optcgapi.com/media/static/Card_Images/OP02-013_p2.jpg"),

            new RespuestaCartaDTO("Sabo (Parallel) (Manga) - Kingdoms of Intrigue (OP04)", "One Piece TCG", "SR",
                "Effect: [Blocker] [On Play] None of your Characters can be K.O.'d by effects until the start of your next turn. Then, draw 2 cards and trash 2 cards from your hand. || Rarity: SR || Number: OP04-083 || Color: Black || Card Type: Character || Cost: 5 || Power: 6000 || Subtype(s): Dressrosa / Revolutionary Army || Attribute: Special",
                590.00, d, (int)(590.00 * d), "https://optcgapi.com/media/static/Card_Images/OP04-083_p2.jpg"),

            new RespuestaCartaDTO("Boa Hancock (Parallel) (Manga) - 500 Years in the Future (OP07)", "One Piece TCG", "SR",
                "Effect: [On Play] Up to 1 of your opponent's Characters cannot attack until the end of your opponent's next turn. Then, place up to 1 Character with a cost of 1 or less at the bottom of the owner's deck. || Rarity: SR || Number: OP07-051 || Color: Blue || Card Type: Character || Cost: 6 || Power: 8000 || Subtype(s): The Seven Warlords of the Sea / Kuja Pirates || Attribute: Special",
                790.00, d, (int)(790.00 * d), "https://optcgapi.com/media/static/Card_Images/OP07-051_p2.jpg"),

            new RespuestaCartaDTO("Tony Tony.Chopper (Parallel) (Manga) - Extra Booster: Memorial Collection (EB01)", "One Piece TCG", "SR",
                "Effect: [Blocker] [DON!! x1] [When Attacking] Give up to 1 of your opponent's Characters -3000 power during this turn. || Rarity: SR || Number: EB01-006 || Color: Red || Card Type: Character || Cost: 3 || Power: 4000 || Subtype(s): Animal / Straw Hat Crew || Attribute: Strike",
                490.00, d, (int)(490.00 * d), "https://optcgapi.com/media/static/Card_Images/EB01-006_p2.jpg")
        );

        java.util.List<RespuestaCartaDTO> actuales = cartaRepo.findAll();
        for (RespuestaCartaDTO nueva : loteInicial) {
            boolean existe = actuales.stream().anyMatch(c -> c.getNombre() != null && c.getNombre().equalsIgnoreCase(nueva.getNombre()));
            if (!existe) {
                cartaRepo.save(nueva);
            }
        }
    }

    @GetMapping("/login")
    public String mostrarLogin(@RequestParam(value = "requerido", required = false) String requerido, Model model) {
        if (requerido != null) {
            model.addAttribute("error", "🔒 Debes iniciar sesión para usar esa función.");
        }
        return "login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String usuario, @RequestParam String password, HttpSession session, Model model) {
        Optional<Usuario> userOpt = usuarioRepo.findByUsernameIgnoreCase(usuario.trim());
        if (userOpt.isPresent() && passwordEncoder.matches(password, userOpt.get().getPassword())) {
            Usuario u = userOpt.get();
            session.setAttribute("usuario", u.getUsername());
            session.setAttribute("rol", u.getRol());
            session.setMaxInactiveInterval(30 * 60);
            return "redirect:/";
        }
        model.addAttribute("error", "Usuario o contraseña incorrectos.");
        return "login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro() { return "registro"; }

    @PostMapping("/registro")
    public String procesarRegistro(@RequestParam String email, @RequestParam String username, @RequestParam String password, @RequestParam String rol, @RequestParam(required = false) String codigoAdmin, Model model) {
        if (usuarioRepo.existsByUsernameIgnoreCase(username.trim())) {
            model.addAttribute("error", "El usuario ya existe.");
            return "registro";
        }
        if ("ADMIN".equalsIgnoreCase(rol) && !"DUALISTA2026".equals(codigoAdmin)) {
            model.addAttribute("error", "Código de Admin incorrecto (Usa: DUALISTA2026).");
            return "registro";
        }
        usuarioRepo.save(new Usuario(username.trim(), email.trim(), passwordEncoder.encode(password), rol.toUpperCase(), true));
        emailService.enviarCorreoBienvenida(email.trim(), username.trim(), rol.toUpperCase());
        model.addAttribute("exito", "📧 ¡Cuenta creada! Hemos enviado un correo de confirmación a " + email.trim() + ". Ya puedes iniciar sesión.");
        return "login";
    }

    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) { session.invalidate(); return "redirect:/login"; }

    @GetMapping("/")
    public String inicio(HttpSession session, Model model) {
        model.addAttribute("usuario", session.getAttribute("usuario"));
        model.addAttribute("rol", session.getAttribute("rol"));
        model.addAttribute("cartas", cartaRepo.findAllByOrderByIdDesc());
        model.addAttribute("ordenes", ordenRepo.findAllByOrderByFechaDesc());
        return "index";
    }

    @GetMapping("/publicar")
    public String publicar(HttpSession session, Model model) {
        Object usuario = session.getAttribute("usuario");
        Object rol = session.getAttribute("rol");
        if (usuario == null || (!"CLIENTE".equals(rol) && !"ADMIN".equals(rol))) {
            return "redirect:/login?requerido=true";
        }
        model.addAttribute("usuario", usuario);
        model.addAttribute("rol", rol);
        return "publicar";
    }

    @PostMapping("/api/cartas/escanear")
    @ResponseBody
    public ResponseEntity<?> escanearCarta(@RequestParam("imagen") MultipartFile archivo, @RequestParam(value = "juego", defaultValue = "Auto-detectar") String juego, HttpSession session) {
        Object usuario = session.getAttribute("usuario");
        Object rol = session.getAttribute("rol");
        if (usuario == null || (!"CLIENTE".equals(rol) && !"ADMIN".equals(rol))) {
            return ResponseEntity.status(401).body(Map.of("error", "Debes iniciar sesión como Cliente o Admin para escanear cartas."));
        }
        if (archivo.isEmpty()) return ResponseEntity.badRequest().body(Map.of("error", "Archivo vacío"));
        try {
            RespuestaCartaDTO detectada = escaneoService.escanearImagenReal(archivo, juego);
            cartaRepo.save(detectada);
            return ResponseEntity.ok(detectada);
        } catch (Exception e) { return ResponseEntity.status(500).body(Map.of("error", e.getMessage())); }
    }

    // =========================================================================
    // PANEL CRUD COMPLETO DE ADMINISTRADOR (CARTAS Y USUARIOS)
    // =========================================================================
    @GetMapping("/admin/panel")
    public String mostrarPanelAdmin(HttpSession session, Model model) {
        if (!"ADMIN".equals(session.getAttribute("rol"))) {
            return "redirect:/login?requerido=true";
        }
        model.addAttribute("usuario", session.getAttribute("usuario"));
        model.addAttribute("rol", session.getAttribute("rol"));
        model.addAttribute("cartas", cartaRepo.findAllByOrderByIdDesc());
        model.addAttribute("usuarios", usuarioRepo.findAll());
        return "admin";
    }

    @PostMapping("/admin/cartas/guardar")
    public String guardarCartaCrud(
            @RequestParam(required = false) String id,
            @RequestParam String nombre,
            @RequestParam String juego,
            @RequestParam String rareza,
            @RequestParam double precioUSD,
            @RequestParam int precioCLP,
            @RequestParam(defaultValue = "5") int stock,
            @RequestParam String estado,
            @RequestParam String imagenUrl,
            HttpSession session) {
        
        if (!"ADMIN".equals(session.getAttribute("rol"))) {
            return "redirect:/login";
        }

        try {
            Long cartaId = (id != null && !id.isBlank() && !id.equals("null")) ? Long.valueOf(id.trim()) : null;
            
            RespuestaCartaDTO carta = (cartaId != null) ? cartaRepo.findById(cartaId).orElse(new RespuestaCartaDTO()) : new RespuestaCartaDTO();
            
            carta.setNombre(nombre.trim());
            carta.setJuego(juego.trim());
            carta.setRareza(rareza.trim());
            carta.setPrecioUSD(precioUSD);
            carta.setPrecioCLP(precioCLP);
            carta.setStock(Math.max(0, stock));
            carta.setDolarHoy(950.0);
            carta.setEstado(estado.trim());
            carta.setImagenUrl(imagenUrl.trim());
            
            cartaRepo.save(carta);
            System.out.println("✅ Carta guardada con éxito en Supabase. ID: " + carta.getId());
        } catch (Exception e) {
            System.out.println("⚠️ Error al guardar en base de datos: " + e.getMessage());
        }

        return "redirect:/admin/panel";
    }

    @PostMapping("/admin/cartas/eliminar/{id}")
    public String eliminarCartaAdmin(@PathVariable Long id, @RequestParam(value = "origen", required = false) String origen, HttpSession session) {
        if ("ADMIN".equals(session.getAttribute("rol"))) cartaRepo.deleteById(id);
        return "admin".equals(origen) ? "redirect:/admin/panel" : "redirect:/";
    }

    @PostMapping("/admin/usuarios/guardar")
    public String guardarUsuarioCrud(
            @RequestParam(required = false) Long id,
            @RequestParam String username,
            @RequestParam String email,
            @RequestParam String rol,
            @RequestParam(required = false) String password,
            HttpSession session) {
        if (!"ADMIN".equals(session.getAttribute("rol"))) return "redirect:/";

        Usuario u = (id != null) ? usuarioRepo.findById(id).orElse(new Usuario()) : new Usuario();
        u.setUsername(username.trim());
        u.setEmail(email.trim());
        u.setRol(rol.trim().toUpperCase());
        u.setVerificado(true);

        if (password != null && !password.isBlank()) {
            u.setPassword(passwordEncoder.encode(password));
        } else if (id == null) {
            u.setPassword(passwordEncoder.encode("123456"));
        }
        usuarioRepo.save(u);

        return "redirect:/admin/panel";
    }

    @PostMapping("/admin/usuarios/eliminar/{id}")
    public String eliminarUsuarioCrud(@PathVariable Long id, HttpSession session) {
        if ("ADMIN".equals(session.getAttribute("rol"))) {
            usuarioRepo.deleteById(id);
        }
        return "redirect:/admin/panel";
    }

    // =========================================================================
    // FLUJO DE PAGO WEBPAY PLUS OFICIAL
    // =========================================================================
    @PostMapping("/comprar/{id}")
    public String comprarCartaWebpay(@PathVariable Long id, HttpSession session, Model model) {
        Optional<RespuestaCartaDTO> cartaOpt = cartaRepo.findById(id);
        if (cartaOpt.isEmpty()) return "redirect:/?error=noEncontrada";
        try {
            RespuestaCartaDTO carta = cartaOpt.get();
            String buyOrder = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            String sessionId = "SES-" + UUID.randomUUID().toString().substring(0, 8);
            String comprador = session.getAttribute("usuario") != null ? session.getAttribute("usuario").toString() : "Invitado";

            int montoSandbox = Math.max(50, carta.getPrecioCLP());

            JsonNode response = webpayService.iniciarTransaccion(buyOrder, sessionId, montoSandbox, "http://localhost:8080/pago/retorno");
            String url = response.get("url").asText();
            String token = response.get("token").asText();

            OrdenCompra nuevaOrden = new OrdenCompra(buyOrder, token, comprador, carta.getId(), carta.getNombre(), carta.getPrecioCLP(), "PENDIENTE");
            ordenRepo.save(nuevaOrden);

            model.addAttribute("url", url);
            model.addAttribute("token", token);
            return "webpay-redirect";
        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/?error=webpay";
        }
    }

    @RequestMapping(value = "/pago/retorno", method = {RequestMethod.GET, RequestMethod.POST})
    public String retornoWebpay(
            @RequestParam(value = "token_ws", required = false) String tokenWs,
            @RequestParam(value = "TBK_TOKEN", required = false) String tbkToken,
            Model model) {

        if (tokenWs == null || tokenWs.isBlank()) {
            if (tbkToken != null) {
                ordenRepo.findByTokenWs(tbkToken).ifPresent(o -> {
                    o.setEstado("ANULADA");
                    ordenRepo.save(o);
                });
            }
            model.addAttribute("mensaje", "El pago fue anulado en el portal de Transbank Webpay.");
            return "pago-fallido";
        }

        try {
            JsonNode response = webpayService.confirmarTransaccion(tokenWs);
            Optional<OrdenCompra> ordenOpt = ordenRepo.findByTokenWs(tokenWs);

            if (response.has("status") && "AUTHORIZED".equals(response.get("status").asText()) && response.path("response_code").asInt(-1) == 0) {
                String buyOrder = response.path("buy_order").asText();
                String codAuth = response.path("authorization_code").asText();
                String cardDigits = response.path("card_detail").path("card_number").asText("6623");
                String tipoPago = response.path("payment_type_code").asText("VD");

                int montoMostrar = response.path("amount").asInt();
                if (ordenOpt.isPresent()) {
                    OrdenCompra o = ordenOpt.get();
                    o.setEstado("PAGADA");
                    o.setCodigoAutorizacion(codAuth);
                    o.setUltimosDigitosTarjeta(cardDigits);
                    o.setTipoPago(tipoPago);
                    ordenRepo.save(o);
                    montoMostrar = o.getMontoCLP();
                    model.addAttribute("nombreCarta", o.getNombreCarta());
                    model.addAttribute("comprador", o.getComprador());
                }

                model.addAttribute("orden", buyOrder);
                model.addAttribute("monto", montoMostrar);
                model.addAttribute("codigoAutorizacion", codAuth);
                model.addAttribute("tarjeta", cardDigits);
                return "pago-exito";
            } else {
                ordenOpt.ifPresent(o -> {
                    o.setEstado("RECHAZADA");
                    ordenRepo.save(o);
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        model.addAttribute("mensaje", "La transacción fue rechazada por Transbank.");
        return "pago-fallido";
    }
}