package cl.rincon.dualista.servicio;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;

@Service
public class WebpayService {

    private static final String URL_BASE = "https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions";
    private static final String COMMERCE_CODE = "597055555532";
    // API Key oficial pública del ambiente de integración de Transbank
    private static final String API_KEY = "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C";

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public JsonNode iniciarTransaccion(String buyOrder, String sessionId, int amount, String returnUrl) throws Exception {
        String body = objectMapper.writeValueAsString(Map.of(
            "buy_order", buyOrder,
            "session_id", sessionId,
            "amount", amount,
            "return_url", returnUrl
        ));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_BASE))
                .header("Tbk-Api-Key-Id", COMMERCE_CODE)
                .header("Tbk-Api-Key-Secret", API_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 200 && response.statusCode() < 300) {
            return objectMapper.readTree(response.body());
        }
        throw new RuntimeException("Error Webpay Create (" + response.statusCode() + "): " + response.body());
    }

    public JsonNode confirmarTransaccion(String token) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL_BASE + "/" + token))
                .header("Tbk-Api-Key-Id", COMMERCE_CODE)
                .header("Tbk-Api-Key-Secret", API_KEY)
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 200 && response.statusCode() < 300) {
            return objectMapper.readTree(response.body());
        }
        throw new RuntimeException("Error Webpay Commit (" + response.statusCode() + "): " + response.body());
    }
}