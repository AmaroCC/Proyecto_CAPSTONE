package cl.rincon.dualista.modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ordenes_compra")
public class OrdenCompra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String buyOrder;

    private String tokenWs;
    private String comprador;
    private Long cartaId;

    @Column(columnDefinition = "TEXT")
    private String nombreCarta;

    private int montoCLP;
    private String estado; // PENDIENTE, PAGADA, RECHAZADA, ANULADA
    private String codigoAutorizacion;
    private String ultimosDigitosTarjeta;
    private String tipoPago;
    private LocalDateTime fecha;

    public OrdenCompra() {}

    public OrdenCompra(String buyOrder, String tokenWs, String comprador, Long cartaId, String nombreCarta, int montoCLP, String estado) {
        this.buyOrder = buyOrder;
        this.tokenWs = tokenWs;
        this.comprador = comprador;
        this.cartaId = cartaId;
        this.nombreCarta = nombreCarta;
        this.montoCLP = montoCLP;
        this.estado = estado;
        this.fecha = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getBuyOrder() { return buyOrder; }
    public void setBuyOrder(String buyOrder) { this.buyOrder = buyOrder; }
    public String getTokenWs() { return tokenWs; }
    public void setTokenWs(String tokenWs) { this.tokenWs = tokenWs; }
    public String getComprador() { return comprador; }
    public void setComprador(String comprador) { this.comprador = comprador; }
    public Long getCartaId() { return cartaId; }
    public void setCartaId(Long cartaId) { this.cartaId = cartaId; }
    public String getNombreCarta() { return nombreCarta; }
    public void setNombreCarta(String nombreCarta) { this.nombreCarta = nombreCarta; }
    public int getMontoCLP() { return montoCLP; }
    public void setMontoCLP(int montoCLP) { this.montoCLP = montoCLP; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getCodigoAutorizacion() { return codigoAutorizacion; }
    public void setCodigoAutorizacion(String codigoAutorizacion) { this.codigoAutorizacion = codigoAutorizacion; }
    public String getUltimosDigitosTarjeta() { return ultimosDigitosTarjeta; }
    public void setUltimosDigitosTarjeta(String ultimosDigitosTarjeta) { this.ultimosDigitosTarjeta = ultimosDigitosTarjeta; }
    public String getTipoPago() { return tipoPago; }
    public void setTipoPago(String tipoPago) { this.tipoPago = tipoPago; }
    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
}