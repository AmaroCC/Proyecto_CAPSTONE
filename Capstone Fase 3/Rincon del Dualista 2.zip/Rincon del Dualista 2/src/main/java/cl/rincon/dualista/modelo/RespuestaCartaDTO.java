package cl.rincon.dualista.modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "cartas")
public class RespuestaCartaDTO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String nombre;

    private String juego;
    private String rareza;

    @Column(columnDefinition = "TEXT")
    private String estado;

    private double precioUSD;
    private double dolarHoy;
    private int precioCLP;
    
    @Column(columnDefinition = "TEXT")
    private String imagenUrl;
    private int stock = 5;

    public RespuestaCartaDTO() {}
    public RespuestaCartaDTO(String nombre, String juego, String rareza, String estado, double precioUSD, double dolarHoy, int precioCLP, String imagenUrl) {
        this.nombre = nombre;
        this.juego = juego;
        this.rareza = rareza;
        this.estado = estado;
        this.precioUSD = precioUSD;
        this.dolarHoy = dolarHoy;
        this.precioCLP = precioCLP;
        this.imagenUrl = imagenUrl;
        this.stock = 5;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getJuego() { return juego; }
    public void setJuego(String juego) { this.juego = juego; }
    public String getRareza() { return rareza; }
    public void setRareza(String rareza) { this.rareza = rareza; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public double getPrecioUSD() { return precioUSD; }
    public void setPrecioUSD(double precioUSD) { this.precioUSD = precioUSD; }
    public double getDolarHoy() { return dolarHoy; }
    public void setDolarHoy(double dolarHoy) { this.dolarHoy = dolarHoy; }
    public int getPrecioCLP() { return precioCLP; }
    public void setPrecioCLP(int precioCLP) { this.precioCLP = precioCLP; }
    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl;
        this.stock = 5; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
}