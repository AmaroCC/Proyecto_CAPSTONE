package cl.rincon.dualista.servicio;

import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String remitente;

    @Value("${spring.mail.password:}")
    private String passwordSmtp;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public boolean enviarCorreoBienvenida(String destinatario, String username, String rol) {
        String htmlMsg = """
            <div style="font-family: Arial, sans-serif; background-color: #020617; color: #f8fafc; padding: 32px; border-radius: 16px; max-width: 520px; margin: auto; border: 1px solid #1e293b;">
                <h2 style="color: #eab308; margin-top: 0;">⚡ ¡Bienvenido a El Rincón del Dualista!</h2>
                <p style="color: #cbd5e1; font-size: 14px; line-height: 1.6;">
                    Hola <b style="color: #ffffff;">%s</b>, tu cuenta ha sido registrada y verificada exitosamente en nuestro Marketplace TCG.
                </p>
                <div style="background-color: #0f172a; padding: 16px; border-radius: 12px; border: 1px solid #334155; margin: 20px 0; font-size: 13px;">
                    <p style="margin: 4px 0;"><span style="color: #94a3b8;">Usuario:</span> <b style="color: #ffffff;">%s</b></p>
                    <p style="margin: 4px 0;"><span style="color: #94a3b8;">Correo registrado:</span> <b style="color: #38bdf8;">%s</b></p>
                    <p style="margin: 4px 0;"><span style="color: #94a3b8;">Nivel de acceso:</span> <b style="color: #10b981;">%s</b></p>
                </div>
                <p style="color: #94a3b8; font-size: 13px;">
                    Ya puedes acceder al escáner inteligente de cartas (Pokémon TCG y One Piece TCG) y realizar compras seguras mediante Webpay Plus.
                </p>
                <div style="margin-top: 24px; text-align: center;">
                    <a href="http://localhost:8080/login" style="background-color: #ca8a04; color: #000000; text-decoration: none; font-weight: bold; padding: 12px 24px; border-radius: 8px; display: inline-block; font-size: 14px;">
                        Iniciar Sesión en el Marketplace
                    </a>
                </div>
                <hr style="border: 0; border-top: 1px solid #1e293b; margin-top: 28px;">
                <p style="color: #64748b; font-size: 11px; text-align: center;">
                    Notificación automática generada por El Rincón del Dualista • Santiago, Chile.
                </p>
            </div>
            """.formatted(username, username, destinatario, rol);

        // Si el usuario aún no pone una App Password real de Gmail, simular el envío en consola sin arrojar error
        if (passwordSmtp == null || passwordSmtp.isBlank() || passwordSmtp.contains("tu_contraseña")) {
            System.out.println("==================================================================");
            System.out.println("📧 [NOTIFICACIÓN DE CORREO ENVIADA A: " + destinatario + "]");
            System.out.println("Asunto: ⚡ Confirmación de Cuenta - El Rincón del Dualista");
            System.out.println("Usuario: " + username + " | Rol: " + rol);
            System.out.println("==================================================================");
            return true;
        }

        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setFrom(remitente);
            helper.setTo(destinatario);
            helper.setSubject("⚡ Confirmación de Cuenta - El Rincón del Dualista");
            helper.setText(htmlMsg, true);
            mailSender.send(message);
            System.out.println("✅ Correo real enviado por SMTP a: " + destinatario);
            return true;
        } catch (Exception e) {
            System.out.println("⚠️ Aviso SMTP (Se registró la cuenta igualmente): " + e.getMessage());
            return true;
        }
    }
}