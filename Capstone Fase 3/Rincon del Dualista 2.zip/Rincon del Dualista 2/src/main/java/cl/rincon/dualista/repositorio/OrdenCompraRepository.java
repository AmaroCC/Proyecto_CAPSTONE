package cl.rincon.dualista.repositorio;

import cl.rincon.dualista.modelo.OrdenCompra;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface OrdenCompraRepository extends JpaRepository<OrdenCompra, Long> {
    Optional<OrdenCompra> findByTokenWs(String tokenWs);
    Optional<OrdenCompra> findByBuyOrder(String buyOrder);
    List<OrdenCompra> findAllByOrderByFechaDesc();
    List<OrdenCompra> findByCompradorIgnoreCaseOrderByFechaDesc(String comprador);
}